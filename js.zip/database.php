<?php
//$conn = new mysqli("localhost", "mycsccf_me", "Hiitisme@94", "mycsccf_csc");
//$conn = new mysqli("mysql14.000webhost.com", "a6637786_pranav", "Hiitisme94", "a6637786_csc");
$conn = new mysqli("localhost", "root", "12345", "csc");
?>
